import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom'
import _ from 'lodash';
import axios from 'axios';

import { User } from '../components/User'
import { Main } from '../components/Main'
import { Posts, editPosts, EditPost } from '../components/Posts'
import { AddPosts } from '../components/AddPost'

import { setName } from '../actions/userActions';
import { getPosts, addPost, deletePost, editPost } from '../actions/posts';
import Modal from 'react-modal';

Modal.setAppElement('#root')
class App extends React.Component {
  constructor() {
    super();
    this.state = {
      title: '',
      body: '',
      id: +new Date(),
      selectedPost: {
        id: '',
        title: '',
        body: ''
      },
      modalIsOpen: false,
      // editedPost:
    }
  }

  componentDidMount() {
    this.props.getPosts()
  };


  addpostsfunction = (e) => {

    this.setState({
      [e.target.name]: e.target.value
    })
  }
  editPostfunction = (e) => {
    this.setState({ selectedPost: { ...this.state.selectedPost, [e.target.name]: e.target.value } })
  }
  openModal = () => {
    console.log('open model')
    this.setState({ modalIsOpen: true });
  }

  editPostFun = (post) => {
    this.setState({ selectedPost: { ...this.state.selectedPost, title: post.title, body: post.body, id: post.id } })
    console.log('selectedPost', this.state.selectedPost);

    this.openModal()
  }
  showPosts = (post) => {
    return <Posts id={post.id} key={post.id} title={post.title} body={post.body} editPost={this.props.editPost} deletePost={this.props.deletePost} editPostFun={this.editPostFun} />
  }
  afterOpenModal = () => {
    // references are now sync'd and can be accessed.
    this.subtitle.style.color = '#f00';
  }
  closeModal = () => {
    console.log('close method')
    this.setState({ modalIsOpen: false });
  }
  handleSubmit = (e) => {
    e.preventDefault()
    this.props.addPost([this.state])
    this.setState({ 'title': '', body: '' })

  }
  render() {
    const posts = _.map(this.props.posts.posts, this.showPosts)
      return (
      <div>
        <h1 ><Link to='/lead'>Lead</Link></h1>
        {/* <Main changename={() => this.props.setName('Anna')} /> */}
        {/* <User username={this.props.user.name} age={this.props.user.age} /> */}
        <AddPosts handleSubmit={this.handleSubmit} titles={this.state.title} body={this.state.body} addpostsfunction={this.addpostsfunction} unqiue_id={this.state.id} />
        {posts}
        {/* {editPosts} */}
        {/* {EditPost} */}

        <Modal
          isOpen={this.state.modalIsOpen}
          onRequestClose={this.closeModal}
          contentLabel="Example Modal"
        >
          <input type="text" value={this.state.selectedPost.title} onChange={this.editPostfunction} name="title" />
          <textarea
            id="exampleFormControlTextarea1"
            rows="10"
            name='body'
            value={this.state.selectedPost.body}
            onChange={this.editPostfunction}
            name='body'>
            {/* {this.state.selectedPost.body} */}
          </textarea>
          <button onClick={() => { this.props.editPost(this.state.selectedPost); this.closeModal(); }}>save</button>
          <button onClick={() => { this.closeModal() }}>close</button>
        </Modal>

      </div>
    )
  }
}


const mapStateToprops = (state) => {
  return {
    user: state.user,
    math: state.math,
    posts: state.posts
  }
}

const mapDispatchToprops = {
  getPosts,
  addPost,
  deletePost,
  editPost
  // deletePost
  // console.log('testing')
  // return {
  //   setAge: (age) => ({
  //     type: "SET_AGE",
  //     payload: age
  //   }),

  //   setName: (name) => {
  //     console.log('ssssssss')
  //     dispatch(setName(name));
  //   },
  //   getPosts: () => {
  //     dispatch(getPosts());
  //   },

  // }
}
export default connect(mapStateToprops, mapDispatchToprops)(App);


