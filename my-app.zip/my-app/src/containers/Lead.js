import React from 'react'
import { displayLead, addLead, editLead, deleteLead } from '../actions/leadAction'
import _ from 'lodash';
import { connect } from 'react-redux';
import { DisplayLeads } from '../components/leadComponents'
import Modal from 'react-modal';
import { ModalComponents } from '../components/modalComponent'

class Lead extends React.Component {
  constructor() {
    super();
    this.state = {
      lead: {
        name: '',
        email: '',
        message: '',
        id: ''
      },
      modelIsOpen: false,
      isEditmodal: false
    }
  }
  componentDidMount() {
    this.props.displayLead()
  }
  showLeads = (lead) => {
    return <DisplayLeads key={lead.id} id={lead.id} name={lead.name} email={lead.email} message={lead.message} editLeadFun={() => this.editLeadFun(lead)} deleteLead={() => this.props.deleteLead(lead)} />
  }
  editLeadFun = (leads) => {
    this.setState({
      lead: {
        ...this.state.lead,
        'id': leads.id, name: leads.name, email: leads.email, message: leads.message
      },
      isEditmodal: true
    })
    this.openModel()
  }
  openModel = () => {
    this.setState({ 'modelIsOpen': true })
  }
  closeModel = () => {
    this.setState({
      lead: {
        ...this.state.lead,
        'id': '', name: '', email: '', message: ''
      },
      isEditmodal: false,
      'modelIsOpen': false
    })
  }
  handleOnChange = (e) => {
    this.setState({
      lead:
        { ...this.state.lead, [e.target.name]: e.target.value }
    })
  }
  submitLead = (lead) => {
    this.state.isEditmodal ? this.props.editLead(lead) : this.props.addLead(lead)
    this.closeModel()
  }
  render() {
    const allLeads = _.map(this.props.lead.leads, this.showLeads)
    return (
      <div>
        <h1>The List of the Posts are</h1>
        <button onClick={this.openModel}> Add new Lead</button>
        {allLeads}
        <Modal isOpen={this.state.modelIsOpen}
          onRequestClose={this.closeModel}
          contentLabel="Example Content">
          Name:- <input type="text" value={this.state.lead.name} name='name' onChange={this.handleOnChange} />
          Email:-<input type="email" value={this.state.lead.email} name='email' onChange={this.handleOnChange} />
          Message :-<textarea
            id="exampleFormControlTextarea1"
            rows="10"
            value={this.state.lead.message}
            onChange={this.handleOnChange}
            name='message'>
          </textarea>
          <button onClick={() => this.submitLead(this.state.lead)}>
            {this.state.isEditmodal ? 'Edit Lead' : 'Add new Lead'}
          </button>
          <button onClick={this.closeModel}>
            Close
          </button>
        </Modal>
      </div>
    )
  }
}

const MapStateToProps = (state) => {
  return {
    lead: state.leads
  }
}

const MapDispatchToprops = {
  displayLead,
  addLead,
  editLead,
  deleteLead
}

export default connect(MapStateToProps, MapDispatchToprops)(Lead)