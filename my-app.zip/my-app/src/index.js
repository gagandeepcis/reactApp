import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from "./containers/App";
import * as serviceWorker from './serviceWorker';
import { render } from 'react';
import { Provider } from "react-redux";
import store from './store';
import Root from './Root'

// ReactDOM.render(<App />, document.getElementById('root'));
// ReactDOM.render((
//     <Provider store={store}>
//         <App></App>
//     </Provider>), document.getElementById('root')
// )
ReactDOM.render(<Root store={store}> </Root>, document.getElementById('root'))