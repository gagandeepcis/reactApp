export function setName(name){
    console.log('testing 1234')
    return dispatch=>{
        setTimeout(()=> {
            console.log('testing ');
            dispatch({
                type : "SET_NAME",
                payload :name
            });
        },2000);
    }
}
export function setAge(age) {
    return{
        type :"SET_AGE",
        payload :age
    };
}