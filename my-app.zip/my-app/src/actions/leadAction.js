import React from 'react'
import axios from 'axios'
import { All_LEADS, ADD_LEADS, EDIT_LEADS, DELETE_LEADS } from './types'

export const displayLead = () => {
  return dispatch => {
    axios.get('http://127.0.0.1:8000/api/lead-list')
      .then((response) => {
        dispatch({
          type: All_LEADS,
          payload: response.data
        })

      })
      .catch((error) => {
        console.log(error)
      });
  }
}

export const addLead = (lead) => {
  return dispatch => {
    axios({
      method: 'post',
      url: 'http://127.0.0.1:8000/api/lead/',
      data: lead
    }).then((response) => {
      dispatch({
        type: ADD_LEADS,
        payload: response.data
      })
    }).catch(() => {
      console.log('Add new Failed')
    })
  }
}

export const editLead = (lead) => {
  return dispatch => {
    axios({
      method: 'put',
      url: (
        'http://127.0.0.1:8000/api/lead-edit-delete/id/').replace('id', lead.id),
      data: lead
    }).then((response) => {
      dispatch({
        type: EDIT_LEADS,
        payload: response.data
      })
    }).catch(() => {
      console.log('Edit Failed')
    });
  }
}

export const deleteLead = (lead) => {
  return dispatch => {
    axios({
      method: 'delete',
      url: (
        'http://127.0.0.1:8000/api/lead-edit-delete/id/').replace('id', lead.id),
    }).then((response) => {
      dispatch({
        type: DELETE_LEADS,
        payload: lead.id
      })
    }).catch(() => {
      console.log('Delete Failed')
    })
  }
}