export function addNumber(number) {
    return {
        type: "ADD",
        payload: number
    };
}
export function setName(name) {
    console.log('testing 1234')
    return dispatch => {
        setTimeout(() => {
            console.log('testing ');
            dispatch({
                type: "SET_NAME",
                payload: name
            });
        }, 12000);
    }
}

export function subtractNumber(number) {
    return {
        type: "SUBTRACT",
        payload: number
    };
}