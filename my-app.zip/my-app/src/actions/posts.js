import axios from 'axios'
import { GET_POSTS, CREATE_POSTS, DELETE_POST, EDIT_POST } from '../actions/types'

export const getPosts = () => {
	return dispatch => {
		axios.get('https://jsonplaceholder.typicode.com/posts')
			.then((response) => {
				dispatch({
					type: GET_POSTS,
					payload: response.data
				});
			})
			.catch((error) => {
				console.log(error);
			});
	}
}


export const addPost = (post) => {
	return dispatch => {
		dispatch({
			type: CREATE_POSTS,
			payload: post
		});
	}
}

export const deletePost = (post) => {
	console.log('action post', post);

	return dispatch => {
		dispatch({
			type: DELETE_POST,
			payload: post
		});
	}
}

export const editPost = (post) => {
	return dispatch => {
		dispatch({
			type: EDIT_POST,
			payload: post
		})
	}
}