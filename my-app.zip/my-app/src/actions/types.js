export const GET_POSTS = 'GET_POSTS'
export const CREATE_POSTS = 'CREATE_POSTS'
export const DELETE_POST = 'DELETE_POST'
export const EDIT_POST = 'EDIT_POST'

export const All_LEADS = 'All_LEADS'
export const ADD_LEADS = 'ADD_LEADS'
export const EDIT_LEADS = 'EDIT_LEADS'
export const DELETE_LEADS = 'DELETE_LEADS'