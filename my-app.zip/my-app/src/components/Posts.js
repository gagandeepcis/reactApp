import React from 'react'

export const Posts = (props) => {
  let toggle = true
  return (
    <div>
      <ul>
        <h1> {props.id} {props.title}</h1>
        <li>{props.body}</li>
        <button onClick={() => {
          props.editPostFun(props)
        }}>Edit</button>
        <pre></pre>
        <button onClick={() => {
          props.deletePost(props.id)
        }}>Delete</button>
      </ul>
      {/* {toggle ? EditPost(props) : ""} */}
    </div >
  )
}

const changeToggle = (post) => {
  console.log('post', post)
  console.log('post', post ? false : true)
  return post ? false : true
}
{/*
const EditPost = (props) => {
  console.log('com', props.body)
  return (
    <div>
      <form onSubmit={props.editPost}>
        Edit the Title<input type='Text' name='title' onChange={props.addpostsfunction} value={props.title} />
        <input type='hidden' value={props.unqiue_id} onChange={props.addpostsfunction} />
        Enter the Descripation
        <textarea
          id="exampleFormControlTextarea1"
          rows="5"
          value={props.body}
          onChange={props.addpostsfunction}
          name='body'>
          {props.body}
        </textarea>
        <button type="Submit" >Add posts</button>
      </form>
    </div>
  )
} */}
