import React from 'react'

export const DisplayLeads = (props) => {
  return (
    <div>
      <ul>
        <li>
          ID:-{props.id}<br />
          Name :-{props.name} <br />
          email :-{props.email} <br />
          message :- {props.message}<br />
          <button onClick={() => { props.editLeadFun(props) }}>Edit</button>
          <button onClick={() => { props.deleteLead(props) }}>
            Delete
          </button>
        </li>
      </ul>
    </div >
  )
}