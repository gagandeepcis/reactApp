import React from 'react'

export const User = (props) =>{
    return(
        <div>
            <h1>
                UserName :- {props.username}
                <br/>
                Age:-{props.age}
            </h1>
        </div>
    )
}
