import React from 'react'
import Modal from 'react-modal'

export const ModalComponents = (props) => {
  return (
    <div>
      <Modal isOpen={props.modelIsOpen}
        onRequestClose={props.closeModel}
        contentLabel="Example Content">
        Name:- <input type="text" value={props.name} name='name' onChange={props.handleOnChange} />
        Email:-<input type="email" value={props.email} name='email' onChange={props.handleOnChange} />
        Message :-<textarea
          id="exampleFormControlTextarea1"
          rows="10"
          value={props.message}
          onChange={props.handleOnChange}
          name='message'>
        </textarea>
        <button onClick={props.submitLead}>
          Add New Post
          </button>
        <button onClick={props.closeModel}>
          Close
          </button>
      </Modal>
    </div>
  )
}