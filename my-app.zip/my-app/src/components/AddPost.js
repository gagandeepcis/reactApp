import React from 'react'

export const AddPosts = (props) => {
  return (
    <div>
      <form onSubmit={props.handleSubmit}>
        Enter the Title<input type='Text' name='title' onChange={props.addpostsfunction} value={props.titles} />
        <input type='hidden' value={props.unqiue_id} onChange={props.addpostsfunction} />
        Enter the Descripation <textarea
              id="exampleFormControlTextarea1"
            rows="5" value={props.body}
              onChange={props.addpostsfunction}
              name='body'>
              {props.body}
            </textarea>
            <button type="Submit" >Add posts</button>

      </form>
    </div>
  )
}