import React from 'react'
import { Provider } from 'react-redux'
import { BrowserRouter as Router, Route } from 'react-router-dom'
import App from './containers/App'
import Lead from './containers/Lead'
import { store } from './store'

const Root = ({ store }) => (
  <Provider store={store}>
    <Router>
      <Route path="/" exact component={App}></Route>
      <Route path="/lead" exact component={Lead}></Route>
    </Router>
  </Provider>
)
export default Root