import { createStore, combineReducers, applyMiddleware } from "redux";
import logger from 'redux-logger'
import thunk from 'redux-thunk';
import rootReducers from './reducers'
import { reducer as formReducer } from 'redux-form'

const store = createStore(
    rootReducers
    , {},
    applyMiddleware(logger, thunk))

// custom Logger
const mylogger = (state) => (next) => (action) => {
    console.log('inside the MyLoggger Function')
    next(action)
}
export default store