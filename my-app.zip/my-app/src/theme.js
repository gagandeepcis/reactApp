// import React from 'react'
// import { directive } from '@babel/types';

// class ThemeSwticher extends React.Component{
//     constructor(){
//        super();
//        this.state = {
//            theme:null
//         } 
//        this.resetTheme = this.resetTheme.bind(this)
//     }
//     resetTheme(e){
//         e.preventDefault();
//         this.setState({'theme' : null})
//     }
    
//     choosetheme(theme,e){
//         e.preventDefault();
//         this.setState({'theme' :theme})
//     }
    
//     render(){
//         const {theme} = this.state.theme
//         const themeClass = theme ? theme.toLowerCase() : 'secondary'
//         return(
//             <div>
//                 <div className="d-flex flex-wrap justify-content-center position-absolute w-100 h-100 align-items-center align-content-center">
//                     <span className = {`h1 mb-4 w-100 text-center text - ${themeClass}`} >{theme || 'Default'} </span>
//                     <div className = 'btn-group'>
//                         <button type = "button" className = {`btn btn-${themeClass} btn-lg dropdown-toggle dropdown-toggle-split` }data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
//                         <span className = "sr-only"> Toggle Theme dropdown</span>
//                         </button>  
//                         <div className = "dropdown-menu" >
//                             <a className = "dropdown-item" href = "#" onClick = {this.choosetheme('Primary',e)}>Primary</a>
//                             <a className = "dropdown-item" href = "#" onClick = {this.choosetheme('Danger',e)}>Danger</a>
//                             <a className = "dropdown-item" href = "#" onClick = {this.choosetheme('Success',e)}>Success</a>
//                         </div>
//                         <div className = "dropdown-menu">
//                             <a className = "dropdown-item" href = "#" onClick = {this.resetTheme}>Reset Theme</a>
//                         </div>
//                     </div>
//                 </div>
//             </div>  
//         )
//     }
// }

// export default ThemeSwticher