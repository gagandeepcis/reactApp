import _ from 'lodash';

import { GET_POSTS, CREATE_POSTS, DELETE_POST, EDIT_POST } from '../actions/types'

const initialState = {
  posts: []
}

export default (state = initialState, action) => {
  switch (action.type) {
    case GET_POSTS:
      return {
        ...state,
        posts: action.payload
      }
    case CREATE_POSTS:
      return {
        ...state,
        posts: state.posts.concat(action.payload)
      }
    case DELETE_POST:

      return {
        ...state,
        posts: _.remove(state.posts, (n) => {
          return n.id != action.payload
        })
      }
      break;
    case 'EDIT_POST':
      return {
        ...state,
        post: _.forEach(state.posts, (n) => {
          if (n.id == action.payload.id) {
            n.title = action.payload.title;
            n.body = action.payload.body
          }
        })
      }
    default:
      return state
  }
}