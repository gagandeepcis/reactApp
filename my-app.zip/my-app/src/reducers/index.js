import { combineReducers } from "redux";
import postReducers from './postReducers';
import userReducers from './userReducer';
import mathReducers from './MathReducer'
import leadReducer from './leadReducer';
import { reducer as formReducer } from 'redux-form'

export default combineReducers({
  posts: postReducers,
  math: mathReducers,
  user: userReducers,
  leads: leadReducer,
  form: formReducer
})