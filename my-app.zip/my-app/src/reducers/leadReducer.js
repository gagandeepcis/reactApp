import _ from 'lodash';

import { All_LEADS, ADD_LEADS, EDIT_LEADS, DELETE_LEADS } from '../actions/types'


const initialState = {
  leads: []
}

export default (state = initialState, action) => {
  switch (action.type) {
    case All_LEADS:
      return {
        ...state,
        leads: action.payload
      }
    case ADD_LEADS:
      console.log('action payload', action.payload);
      return {
        ...state,
        leads: [action.payload, ...state.leads]
      }
    case EDIT_LEADS:
      return {
        ...state,
        leads: _.forEach(state.leads, (n) => {
          if (n.id === action.payload.id) {
            n.id = action.payload.id
            n.name = action.payload.name
            n.email = action.payload.email
            n.message = action.payload.message
          }
        })
      }
    case DELETE_LEADS:
      return {
        ...state,
        leads: _.remove(state.leads, (n) => {
          return n.id !== action.payload
        })
      }
    default:
      return state
  }
}

