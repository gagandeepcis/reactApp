// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';
// import App from './App';
// import * as serviceWorker from './serviceWorker';

// ReactDOM.render(<App />, document.getElementById('root'));

// // If you want your app to work offline and load faster, you can change
// // unregister() to register() below. Note this comes with some pitfalls.
// // Learn more about service workers: https://bit.ly/CRA-PWA
// serviceWorker.unregister();

import {render} from "react-dom";
import React from "react";
import {createStore} from "redux";

const intialState = {
    result : 1,
    lastValues :[],
    username :'GD'
};

const reducer = (state = intialState,action) =>{
  switch(action.type){
    case "ADD":
    //   state = state + action.payload
    //   state.result += action.payload
    //   break;
        state = {
            ...state,
            result: state.result + action.payload,
            lastValues :[...state.lastValues,action.payload]
        }
        break;
    case "SUBTRACT":
        state = {
            ...state ,
            result: state.result - action.payload,
            lastValues : [...state.lastValues,action.payload]
        }
        break;
    }
    return state
}
const store = createStore(reducer)

store.subscribe(()=>{
  console.log("Store Updated",store.getState())
})

store.dispatch({
  type : 'ADD',
  payload : 100
});

store.dispatch({
    type : 'ADD',
    payload : 10
  });

store.dispatch({
    type:'SUBTRACT',
    payload :100
  })


//new 
import {render} from 'react'
import React from 'react'
import {createStore,combineReducers, applyMiddleware} from "redux";
import logger from 'redux-logger'

const MathReducer = (state = {
    result : 1,
    lastValues :[],
},action)=>{
    switch(action.type){
        case "ADD":
            state = {
                ...state,
                result: state.result + action.payload,
                lastValues :[...state.lastValues,action.payload]
            }
            break;
        case "SUBTRACT":
            state = {
                ...state ,
                result: state.result - action.payload,
                lastValues : [...state.lastValues,action.payload]
            }
            break;
    }
    return state
}   

const  userReducer = (state = {
    name : 'Max',
    age : 27
    }, action)=> {
    switch(action.type){
        case "SET_NAME":
            state ={
                ...state,
                name : action.payload
            }
            break;
        case "SET_AGE":
            state =  {
                ...state,
                age:action.payload
            }
        break;
    }
    return state
    
}
const mylogger = (state) => (next) => (action) =>{
    console.log('inside the MyLoggger Function')
    next(action)
}
const store = createStore(
    combineReducers({MathReducer,userReducer})
    ,{},
    applyMiddleware(logger))

store.subscribe(() =>{
    // console.log('Store state',store.getState());
})

store.dispatch({
    type : 'SET_NAME',
    payload : 'Gagandeep'
})

store.dispatch({
    type : 'SET_AGE',
    payload : 24
})

store.dispatch({
    type : 'ADD',
    payload : 85
})

store.dispatch({
    type : 'SUBTRACT',
    payload : 100
})